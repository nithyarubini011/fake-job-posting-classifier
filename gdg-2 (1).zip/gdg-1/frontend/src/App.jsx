import { useState } from "react";

function App() {
  const [message, setMessage] = useState("");
  const [domain, setDomain] = useState("");
  const [result, setResult] = useState(null);

  const verifyInternship = async () => {
    try {
      const res = await fetch("http://127.0.0.1:5000/api/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, domain })
      });

      const data = await res.json();
      setResult(data);
    } catch (err) {
      alert("Backend not running");
    }
  };

  return (
    <div style={{ padding: 40, maxWidth: 700, margin: "auto" }}>
      <h1>InternShield</h1>
      <p>Fake Internship & Scam Detector</p>

      <input
        placeholder="Email or Company Domain"
        value={domain}
        onChange={(e) => setDomain(e.target.value)}
        style={{ width: "100%", padding: 10 }}
      />

      <br /><br />

      <textarea
        placeholder="Paste internship message here"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        rows={6}
        style={{ width: "100%", padding: 10 }}
      />

      <br /><br />

      <button onClick={verifyInternship}>
        Verify Internship
      </button>

      {result && (
        <div style={{ marginTop: 30 }}>
          <h2>{result.verdict}</h2>
          <p><b>Risk Score:</b> {result.risk_score}</p>
          <ul>
            {result.reasons.map((r, i) => (
              <li key={i}>{r}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default App;
