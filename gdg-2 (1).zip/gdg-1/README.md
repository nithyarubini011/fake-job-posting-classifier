
# InternShield – Fake Internship & Scam Detector

## Run Backend
cd backend
pip install -r requirements.txt
python app.py

## Run Frontend
cd frontend
npm install
npm run dev
